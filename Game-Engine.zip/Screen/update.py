import pygame
import Objects
import time
from loadData import data, screen, quickData

def run():
  #screen.fill(data["background"])
  print("moving Image")
  Objects.imageObj.call("move")
  
  print("Updating Screen")
  
  Objects.screenObj.call("fill")
  
  objectDict = Objects.getObjectDict()
  for object in quickData["renderQueue"]:
    objectDict[object].call("new_render")
  
  #draw the pixels on the screen
  print("drawing pixels")
  pixels = quickData["pixels"]
  
  index = 0
  x = 0
  y = 0
  
  while index < len(pixels):
    if pixels[index] == ".":
      y += 1
      x = 0
      index += 1
    else:
      colour = pixels[index: index+9]
      if colour != "/////////":
        try:
          colour = (int(colour[0:3]), int(colour[3:6]), int(colour[6:9]))
          screen.set_at((x,y), colour)
        except:
          print(pixels[index: index+9])
          print("COLOUR NOT VALID:", colour)
          time.sleep(10000)
      
      index += 9
      x += 1
  pygame.display.update()