from loadData import quickData, data
import pygame

def tupleToString(colour):
  string = ""
  for i in colour:
    s = str(i)
    while len(s) < 3:
      s = "0" + s
    string += s
  return string


def run():
  print("filling screen")
  
  if type(data["background"]) == tuple:
    quickData["pixels"] = (tupleToString(data["background"]) * data["width"] + ".") * data["height"]
    
  elif type(data["background"]) == str:
    quickData["pixels"] = ""

    open texture file and draw it to the screen
    
    for i in range(data["height"]):
      for j in range(data["width"]):
        if type(data["background"]) == tuple:
          quickData["pixels"] +=  # Adapt this code (use render.py to help)
      quickData["pixels"] += "."
  print("screen filled")