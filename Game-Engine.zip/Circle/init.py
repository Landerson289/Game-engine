import math as maths

def run():
  texture = ""
  for i in range(25):
    size = 25 * 2 * maths.sqrt(- (i/25)**2 + 2*(i/25))
    size = int(size//1)
    
    texture += int(size//2)*"-" + size * "255000000" + "."
  for i in range(25):
    size = 25 * 2 * maths.sqrt(- ((25 - i)/25)**2 + 2*((25-i)/25))
    size = int(size//1)
    
    texture += int(size//2)*"-" + size * "255000000" + "."

  f = open("Circle/texture", "w")
  f.write(texture)
  f.close()