import Objects
import pygame
import time
import os
import math as maths
from loadData import quickData, screen

quickData["currentObject"] = None

###########################
### Goal 1: Flappy Bird ###
###########################

### If the position is less than 0 it will wrap around because it is a negative list index. This could be solved with a simple if statement except for sectioning so a more advanced solution will be needed. This should still look like a boundary (do upperbound as well)

### Image backgrounds

### Collision hitboxes

### Text rendering

### Fixed update + deltaTime

### Optimisation

###########################
### Goal 2: Beyond that ###
###########################

### Editor

### 



print("initialising objects")

Objects.defaultObj.call("init")
Objects.screenObj.call("init")
Objects.squareObj.call("init")
Objects.triangleObj.call("init")
Objects.outlineObj.call("init")
Objects.circleObj.call("init")
Objects.imageObj.call("init")


def run():
  while True:
    startTime = time.time()
    # Figure out where to put this
    quickData["renderQueue"].append(Objects.triangleObj.name) 
    quickData["renderQueue"].append(Objects.squareObj.name)
    quickData["renderQueue"].append(Objects.outlineObj.name)
    quickData["renderQueue"].append(Objects.circleObj.name)
    quickData["renderQueue"].append(Objects.imageObj.name)
    Objects.screenObj.call("update")
    quickData["renderQueue"] = []
    
    print("done")
    endTime = time.time()
    print("fps = " + str(1/(endTime - startTime)))
    #time.sleep(10000)
run()