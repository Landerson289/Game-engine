#The texture holds a pixel array of the object with 255150000 refering to (255, 150, 0)
#Other characters are ///////// for a transparent texture and . for next line.
import time # for testing
import loadData
import Objects

def insertPixel(pixels, pixel, pos):
  rows = pixels.split(".")
  row = rows[pos[1]]
  newRow = row[0:9*pos[0]] + pixel + row[9*pos[0]+9:]
  newPixels = ""
  for i in range(len(rows)):
    if i != pos[1]:
      newPixels += rows[i] + "."
    else:
      newPixels += newRow + "."
  return newPixels
  
def run():
  print("rendering texture")
  
  objDict = Objects.getObjectDict()
  objectName = loadData.quickData["currentObject"]
  
  object = objDict[objectName]
  
  texture = open(objectName + "/texture").read()
  localData = loadData.load(objectName + "/data")
  position = [localData["x"], localData["y"]]
  
  pixels = loadData.quickData["pixels"]
  #print(pixels)
  
  #render the image on top of the pixels
  rows = texture.split(".")
  y = 0
  for row in rows:
    x = 0
    if y%5 == 0:
      print(y/len(rows)*100)
  
    
    
    while row != "":
      while row[0] == "-":
        x -= 1
        row = row[1:]
      pixel = row[0:9]
      row = row[9:]
      #print(pixel)
      #get the position
      pixelPos = [position[0] + x, position[1] + y]
      #adjust that pixel in the list, check if its /////////
      if pixel == "/////////":
        pass
      else:
        loadData.quickData["pixels"] = insertPixel(loadData.quickData["pixels"], pixel, pixelPos)
      x += 1
    y += 1