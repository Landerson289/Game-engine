def run():
  texture = ""
  for i in range(50):
    for j in range(50):
      if i == 0 or i == 49 or j == 0 or j == 49:
        texture += "255000000"
      else:
        texture += "/////////"
    texture += "."

  f = open("Outline/texture", "w")
  f.write(texture)
  f.close()