def run():
  square = ""
  for i in range(50):
    for j in range(50):
      red = str(i*4)
      if i*4 < 10:
        red = "00" + red
      elif i*4 < 100:
        red = "0" + red
  
      green = str(j*4)
      if j*4 < 10:
        green = "00" + green
      elif j*4 < 100:
        green = "0" + green
      
      square += red + green + "000"
    square += "."

  f = open("Square/texture", "w")
  f.write(square)
  f.close()