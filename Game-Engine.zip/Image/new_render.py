#The texture holds a pixel array of the object with 255150000 refering to (255, 150, 0)
#Other characters are ///////// for a transparent texture and . for next line.
import time # for testing
import loadData
import Objects
from loadData import data


def insert_pixels(texture, pixels, pos):
  rows = texture.split(".")
  row = rows[pos[1]]
  newRow = row[0:int(9*pos[0])] + pixels + row[int(pos[0]*9 + len(pixels)):]
  newTexture = ""
  for i in range(len(rows)):
    if i != pos[1]:
      newTexture += rows[i] + "."
    else:
      newTexture += newRow + "."
  return newTexture
  
def run():
  objDict = Objects.getObjectDict()
  objectName = loadData.quickData["currentObject"]
  
  object = objDict[objectName]
  
  texture = open(objectName + "/texture").read()
  localData = loadData.load(objectName + "/data")
  position = [localData["x"], localData["y"]]
  
  rows = texture.split(".")
  y = 0
  for row in rows:
    x = 0
    if len(row) > 0:
      while row[0] == "-":
        x -= 1
        row = row[1:]
      if "/" not in row:
        pixelPos = [x+position[0], y+position[1]]
        loadData.quickData["pixels"] = insert_pixels(loadData.quickData["pixels"], row, pixelPos)
      else:
        sections = row.split("/////////")
        for section in sections:
          if section != "":
            pixelPos = [x+position[0], y+position[1]]
            loadData.quickData["pixels"] = insert_pixels(loadData.quickData["pixels"], section, pixelPos)
          x += len(section)/9 + 1
    y += 1