import pygame
import loadData

def run():
  localData = loadData.load("Image/data")
  image = localData["image"]
  height = localData["height"]
  width = localData["width"]
  localData["x"] = 0
  loadData.upload("Image/data", localData)
  surface = pygame.image.load(image)
  surface = pygame.transform.scale(surface, (width,height))
  texture = ""
  for y in range(surface.get_height()):
    for x in range(surface.get_width()):
      colour = surface.get_at((x,y))
      if colour[3] >= 0.5:
        string = ""
        for i in range(3):
          s = str(colour[i])
          while len(s) != 3:
            s = "0" + s
          string += s
      else:
        string = "/////////"
      texture += string
    texture += "."

    f = open("Image/texture", "w")
    f.write(texture)
    f.close()