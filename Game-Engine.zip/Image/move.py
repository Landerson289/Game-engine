import loadData

def run():
  localData = loadData.load("Image/data")
  localData["x"] += 25

  loadData.upload("Image/data", localData)