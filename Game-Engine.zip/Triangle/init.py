def run():
  triangleRows = ["000255000"]
  for i in range(49):
    row = triangleRows[-1]
    #row = "-" + row
    red = str(50+i*4)
    while len(red) != 3:
      red = "0" + red
    row += red + "000000"
    triangleRows.append(row)
  
  triangle = ""
  for i in triangleRows:
    triangle += i + "."
  
  f = open("Triangle/texture", "w")
  f.write(triangle)
  f.close()
